<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2021-05-24 21:38:30 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/365exchange/application/modules/admin/controllers/Casino.php 725
ERROR - 2021-05-24 21:38:31 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:32 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:32 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:32 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/365exchange/application/modules/admin/controllers/Casino.php 725
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/365exchange/application/modules/admin/controllers/Casino.php 725
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/365exchange/application/modules/admin/controllers/Casino.php 725
ERROR - 2021-05-24 21:38:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/365exchange/application/modules/admin/controllers/Casino.php 725
ERROR - 2021-05-24 21:38:37 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:38 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:39 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:39 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:39 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:39 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:39 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:42 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:42 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:43 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:44 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:45 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:45 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:45 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:46 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:46 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:46 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:38:47 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:48 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:49 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:50 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:50 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:51 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:52 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:52 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:52 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:52 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:52 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:52 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:53 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:53 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:53 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:54 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:38:59 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:00 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:01 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:08 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:09 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:10 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:10 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:10 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:10 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:11 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:11 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:11 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:11 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:11 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:11 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:11 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:15 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:17 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:18 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:18 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:19 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:20 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:21 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:24 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:26 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:27 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:28 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:29 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:32 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:33 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:33 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:34 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:37 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:38 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:38 --> Severity: Warning --> min(): Array must contain at least one element /var/www/html/365exchange/application/helpers/common_helper.php 823
ERROR - 2021-05-24 21:39:40 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:40 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:40 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:40 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:40 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:40 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:40 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:40 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:40 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:41 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> 404 Page Not Found: /index
ERROR - 2021-05-24 21:39:41 --> Severity: Warning --> array_merge(): Argument #2 is not an array /var/www/html/365exchange/application/helpers/common_helper.php 2652
ERROR - 2021-05-24 21:39:41 --> Severity: Core Warning --> PHP Startup: Unable to load dynamic library '/usr/lib/php/20131226/php_mysqli.dll' - /usr/lib/php/20131226/php_mysqli.dll: cannot open shared object file: No such file or directory Unknown 0
ERROR - 2021-05-24 21:39:41 --> 404 Page Not Found: /index
