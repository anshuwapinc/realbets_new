<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');




//*************************Commonly Used*************************
$lang['SITENAME'] = "Sports Book";
$lang['contact_phone_header'] = 'You can reach us at +331.02.03.04.05';
$lang['login_btn_signin'] = "Sign In";

$lang['team_name'] = "Team";
$lang['team_logo'] = "Logo";
$lang['player_name'] = "Player";
$lang['prediction_title'] = "Match Title";
$lang['prediction_entry_from'] = "Start";
$lang['prediction_entry_to'] = "End";
$lang['description'] = "Description";
$lang['user_name'] = "User Name";

$lang['contact_no'] = "Contact No";

$lang['whatsapp_no'] = "Whatsapp No";

$lang['address'] = "Address";
$lang['status'] = "Status";
$lang['edit'] = "Edit";

$lang['delete'] = "Delete";

$lang['user_id'] = "User ID";
$lang['winings'] = "Winings";
$lang['credit_limit'] = "Credit Limits";
$lang['exposure'] = "Exposure";
$lang['balance'] = "Balance";
$lang['partnership'] = "Partnership";
$lang['casino_partnership'] = "Partnership Casino";
$lang['teenpati_partnership'] = "Partnership Teenpati";
$lang['master_commision'] = "M. Comm.";
$lang['sessional_commision'] = "S. Comm.";
$lang['view_more'] = "View More";
$lang['user_name'] = 'User ID';
$lang['user_checkbox'] = ' ';

$lang['betting_id'] = 'Round Id';
$lang['place_name'] = 'Place Name';
$lang['user_name'] = 'User Name';
$lang['created_at'] = 'Date';
$lang['stake'] = 'Stake';
$lang['price_val'] = 'Price';
$lang['bet_result'] = 'Bet Result';
$lang['betting_check_box'] = ' ';
$lang['seperate_password'] = 'M. Password';








 
