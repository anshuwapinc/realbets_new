<?php

    if (!defined('BASEPATH'))
        exit('No direct script access allowed');

    $lang['language_listing_headers'] = array(
        'languagename' => 'Language Name',
        'languageimage' => 'Default',
        'edit' => 'Edit',
        'delete' => 'Delete'
    );

    $lang['portfolio_listing_headers'] = array(
        'portfolio_title' => 'Portfolio Title',
        'portfolio_content' => 'Portfolio Content',
        'edit' => 'Edit',
        'delete' => 'Delete'
    );

    $lang['news_listing_headers'] = array(
        'news_title' => 'News Title',
        'edit' => 'Edit',
        'delete' => 'Delete'
    );
      $lang['slider_listing_headers'] = array(
        'slider_title' => 'Slider Title',
        'edit' => 'Edit',
        'delete' => 'Delete'
    );

    